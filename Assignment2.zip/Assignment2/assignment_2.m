%%YEVGEN SOLODKYY
%%Assignment 2
close all
clear all
clc

%read image
A=imread('Squid.jpg');
A=rgb2gray(A);
A=double(A);
len=256;
B=imresize(A,[len,len],'bicubic');
figure(1);
imagesc(B);
colormap gray(256);
title('Original')
%build Haar filter matrix
Q=[1 1;1 -1];I = eye(len);
H = kron(I(1:len/2,1:len/2),Q)/sqrt(2);
%build permutation matrix
PT = I([1:2:len],:);
PB = I([2:2:len],:);
%encode image
len
for j = 1:log2(len)
    P=[PT(1:len/2, 1:len); PB(1:len/2,1:len)];
    H = H(1:len,1:len);
    B(1:len,1:len)=P*H*B(1:len,1:len)*H'*P'; %
    len = len/2
end
figure(2);
image(B);
colormap hot(16);
title('Encoded')

%% Threshold
th80 = threshold(B,.80);

B_th80 = B.*(B>th80);

figure(3);
image(B_th80);
colormap hot(16);
title('Thresholded at .80')

th90 = threshold(B,.90);
B_th90 = B.*(B>th90);

figure(4);
image(B_th90);
colormap hot(16);
title('Thresholded at .90')


th95 = threshold(B,.95);
B_th95 = B.*(B>th95);

figure(5);
image(B_th95);
colormap hot(16);
title('Thresholded at .95')

%% Quantize

log_quant(B,.80,8)

