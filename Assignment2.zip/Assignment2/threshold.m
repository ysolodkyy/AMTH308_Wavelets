function th = threshold(B,cutoff)
%Step 1: Get Threshold
[len,len] = size(B);
X = sort(abs(B(:)));
th = X(floor(cutoff*len^2));%+eps;