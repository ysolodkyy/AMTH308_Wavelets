clc
close all
clear all
syms z f

% calculate the inverse Fourier transform of the expression I gave for phi_hat.
% recall the FT property FT{X(t)} <=> x(-f)

%x = heaviside(z+.5)-heaviside(z-.5);
%F=8.1; N=128; M=1;
%[Xs,fs]=f_trans(x,F,N,M)
%figure(1)
%plot(fs,Xs);%x = heaviside(z+.5)-heaviside(z-.5);
%F=8.1; N=128; M=1;
%[Xs,fs]=f_trans(x,F,N,M)


%% define the phi_hat function

w = 2*pi*z;

N1 = 5+30*cos(w/2)^2+30*sin(w/2)^2*cos(w/2)^2;
N2 = 2*sin(w/2)^4*cos(w/2)^2+70*cos(w/2)^4+2/3*sin(w/2)^6;

S = (N1+N2)/(105*sin(w/2)^8);

% scaling function FT:
phi_hat = 16/(w^4*sqrt(S)+eps)

%% plot Phi_hat

figure(2)
ezplot(phi_hat, [-2 2])
title("phi_hat");

%% define the symbol 

P = subs(phi_hat,z,2*f)/subs(phi_hat,z,f);

%% calculate coefficients

[DC,hp,hn]=f_coeff(P*sqrt(2),1,23)  % so is it f_coeff(sqrt(2)*P,1,23) or f_coeff(sqrt(2),1,23) or f_coeff(P,1,23)?
k =-11:11;
"filter coefficients"
h = [fliplr(hn) DC hp]

figure(3)
stem(k, h)
title("filter coeff")

%% part 7-4
%{
Another approach to finding phi(t), IFF the filter coefficients are known,
is to iteratively solve the dilation equation

phi(t) = SUM_k (h_k*sqrt(2)*phi(2*t-k)

with unit pulse as the zero'th iterate 
%}
% we know the filter coefficients as h for  -11 <=k<= 11

%% PLot the scaling function see page 12

syms t

Phi_0 = heaviside(t)-heaviside(t-1);
%figure(4); 

%ezplot(Phi_0, [0,3])

%{
the Cascade algorithm should look something like this:

for k=-11:11
        Phi=Phi+sqrt(2)*h(k+12)*subs(Phi_0,t,2*t-k);
    end

%}

for m=1:7
    Phi=0;
    for k=-11:11
        Phi=Phi+sqrt(2)*h(k+12)*subs(Phi_0,t,2*t-k);
    end

Phi_0 = Phi;

%pause(.3);
end

figure(4)
ezplot(Phi, [-6,6, -1, 1.5]);
title("Scaling Function Phi(t)");


%% mother wavelet see page 13

Psi = 0;
h_bar = flip(h);
 for k=-11:11
        Psi=Psi+(-1)^(k)*sqrt(2)*h_bar(k+12)*subs(Phi,t,2*t-k);
 end

figure(5)
ezplot(Psi, [-6,6 -1, 1.5]);
title("Mother Function Psi(t)");

