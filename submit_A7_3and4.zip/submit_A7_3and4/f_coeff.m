function [dc,hp,hn]=f_coeff(x,T,N)
% x: symbolic periodic function
% T: period of x
% N: number of coeffs to calculate (odd positive integer)
% hp: Fourier coefficients x_hat(m) for m=1,...,floor(N/2)
% hn: Fourier coefficient of x_hat(m) for m=-1,-2,...,-floor(N/2)
syms f real
dt = T/N;
x_sample(1) = double(limit(x,f,0));

for k=2:N
x_sample(k) = double(subs(x,f,(k-1)*dt));
end

tmp = fft(x_sample)/N;
dc=tmp(1);

for m=1:floor(N/2)
hp(m) = tmp(m+1);
hn(m) = tmp(N+1-m);
end