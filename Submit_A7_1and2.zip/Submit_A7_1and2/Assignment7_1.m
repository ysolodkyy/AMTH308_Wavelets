clear all;
clc
close all;

syms z

%{
% probably should solve for these
h0 = 0.47046721;
h1 = 1.14111692;
h2 = 0.650365;
h3 = -0.19093442;
h4 = -0.12083221;
h5 = 0.0498175;
%}
[h0,h1,h2,h3,h4,h5] = solve('h0^2+h1^2+h2^2+h3^2+h4^2+h5^2-1=0','h0+h1+h2+h3+h4+h5-sqrt(2)=0','h0-h1+h2-h3+h4-h5=0','h1-2^2*h2+3^2*h3-4^2*h4+5^2*h5=0','h0*h2+h3*h5+h2*h4=0','h1-2*h2+3*h3-4*h4+5*h5=0');


k = 1;
h0=double(real(h0(k)));
h1=double(real(h1(k)));
h2=double(real(h2(k)));
h3=double(real(h3(k)));
h4=double(real(h4(k)));
h5=double(real(h5(k)));

h=[h0 h1 h2 h3 h4 h5];



p=0;
for k = 0:5
p = p+1/sqrt(2)*h(k+1)*exp(-2*pi*j*z*k); % this may not be entirely correct. Consider doing symsubs
end

p

figure(1)
ezplot(abs(p), [0,1]) % this worked
title("Symbol P(z)");

%% PLot the scaling function see page 12

syms t

Phi_0 = heaviside(t)-heaviside(t-1);
figure(2); 
ezplot(Phi_0, [0,3])


for m=1:7
    Phi=0;
    for k=0:5
        Phi=Phi+sqrt(2)*h(k+1)*subs(Phi_0,t,2*t-k);
    end
figure(m+3)
ezplot(Phi, [0,3]);
title("Scaling Function Phi(t)");
Phi_0 = Phi;

%pause(.3);
end


%% mother wavelet see page 13

Psi = 0;

 for k=0:3
        Psi=Psi+(-1)^(k)*sqrt(2)*h(4-k)*subs(Phi,t,2*t-k);
 end

figure(m+3)
ezplot(Psi, [0,3]);
title("Mother Function Psi(t)");
