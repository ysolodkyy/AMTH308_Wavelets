%% part 1

clear all;
clc
close all;

%{
syms h0 h1 h2 h3 h4 h5 z

%eqns = [2*u^2 + v^2 == 0, u - v == 1];
%vars = [v u];
%[solv, solu] = solve(eqns, vars)

%[h0,h1,h2,h3,h4,h5] = solve(h0^2+h1^2+h2^2+h3^2+h4^2+h5^2-1==0,h0+h1+h2+h3+h4+h5-sqrt(2)==0,h0-h1+h2-h3+h4-h5==0,h1-2^2*h2+3^2*h3-4^2*h4+5^2*h5==0,h0*h2+h3*h5+h2*h4==0,h1-2*h2+3*h3-4*h4+5*h5==0);
vars = [h0 h1 h2 h3 h4 h5];
[H0 H1 H2 H3 H4 H5] = solve(h0^2+h1^2+h2^2+h3^2+h4^2+h5^2-1==0,h0+h1+h2+h3+h4+h5-sqrt(2)==0,h0-h1+h2-h3+h4-h5==0,h1-2^2*h2+3^2*h3-4^2*h4+5^2*h5==0,h0*h2+h3*h5+h2*h4==0,h1-2*h2+3*h3-4*h4+5*h5==0);
   
   H0 = vpa(H0)
   H1 = vpa(H1)
   H2 = vpa(H2)
   H3 = vpa(H3)
   H4 = vpa(H4)
   H5 = vpa(H5)

clear h0 h1 h2 h3 h4 h5


k = 1;
h0=H0(k);
h1=H1(k);
h2=H2(k);
h3=H3(k);
h4=H4(k);
h5=H5(k);



h=[h0 h1 h2 h3 h4 h5]


p=0;
for k = 0:5
p = p+1/sqrt(2)*h(k+1)*exp(-2*pi*j*z*k); % this may not be entirely correct. Consider doing symsubs
end

p

figure(1)
ezplot(abs(p), [-1/2,1/2]) % this worked
title("Symbol P(z)");

%}

syms z f
w = 2*pi*z;

N1 = 5+30*cos(w/2)^2+30*sin(w/2)^2*cos(w/2)^2;
N2 = 2*sin(w/2)^4*cos(w/2)^2+70*cos(w/2)^4+2/3*sin(w/2)^6;

S = (N1+N2)/(105*sin(w/2)^8);

% scaling function FT:
phi_hat = 16/(w^4*sqrt(S)+eps);

%% plot Phi_hat
%{
figure(1)
ezplot(phi_hat, [-2 2])
title("phi_hat");
%}
%% define the symbol 

"part 1:"

P = subs(phi_hat,z,2*z)/phi_hat

figure(2)
ezplot(abs(P), [-1/2 1/2])
title("abs(P)");

%% part 2

"part 2:"
exponent = -1*exp(-1i*pi*z);

%sigma_hat = subs(P,f,(f+1)/2)*subs(phi_hat,z,f/2); %-1*exp(-1i*pi*f);%*
sigma_hat = exponent*subs(P,z,(z+1)/2)*subs(phi_hat,z,z/2) %-1*exp(-1i*pi*f);%*

figure(3)
ezplot(abs(sigma_hat), [-3 3])
title("abs(sigma-hat)");
