clear all;
clc;

LA  = [0.03314563036812 -0.06629126073624 -0.17677669529664 0.41984465132951 0.99436891104358 0.41984465132951 -0.17677669529664 -0.06629126073624 0.03314563036812];
LS  = [0 0 0 0.35355339059327 0.70710678118655 0.35355339059327 0 0 0];



%create HIGH_PASS coefficients

HA = [-LS(1) LS(2) -LS(3) LS(4) -LS(5) LS(6) -LS(7) LS(8) -LS(9)];

HS = [-LA(1) LA(2) -LA(3) LA(4) -LA(5) LA(6) -LA(7) LA(8) -LA(9)];
%% get coefficients for ease of use
LA4 = LA(1);
LA3 = LA(2);
LA2 = LA(3);
LA1 =  LA(4);
LA0 =  LA(5);

HA4 = HA(1);
HA3 = HA(2);
HA2 = HA(3);
HA1 = HA(4);
HA0 = HA(5);

LS4 =LS(1);
LS3 =LS(2);
LS2 =LS(3);
LS1 =LS(4);
LS0 =LS(5);

HS4 =HS(1);
HS3 =HS(2);
HS2 =HS(3);
HS1 =HS(4);
HS0 =HS(5);
%% for encoding use LA & HA

UPPER_LEFT = [LA0 LA1+LA1 LA2+LA2 LA3+LA3 LA4+LA4 0 0 0; HA1 HA0+HA2 HA1+HA3 HA2+HA4 HA3 HA4 0 0; LA2 LA1+LA3 LA0+LA4 LA1 LA2 LA3 LA4 0; HA3 HA2+HA4 HA1 HA0 HA1 HA2 HA3 HA4];

LOWER_RIGHT = [LA4 LA3 LA2 LA1 LA0 LA1 LA2+LA4 LA3; 0 HA4 HA3 HA2 HA1 HA0+HA4 HA3+HA1 HA2; 0 0 LA4 LA3 LA2+LA4 LA3+LA1 LA2+LA0 LA1; 0 0 0 HA4+HA4 HA3+HA3 HA2+HA2 HA1+HA1 HA0];

Q = [LA 0; 0 HA]; %[7*ones(1,9) 0; 0 3*ones(1,9)]%


%read image
A0=imread('Squid.jpg');
A0=rgb2gray(A0);
A0=double(A0);
len=256;
B=imresize(A0,[len,len],'bicubic');

A1=B; % use for MSE calculations


%% Show the image

figure(1);
imagesc(B);
colormap gray(256);
title('256x256 grayscale of original')

len = 256;
% so this should work for all sizes of matrices
I = eye(len);
PT = I([1:2:len],:);
PB = I([2:2:len],:);


for m = 1:log2(len)-3 % using the "-1" reduces the H matrix to 4x4. Using "-2" reduces the matrix to 8x8
    P=[PT(1:len/2, 1:len);
        PB(1:len/2,1:len)];
    
    H = zeros(len,len);
    
    H(1:4,1:8) = UPPER_LEFT;
    H(len-3:len,len-7:len)=LOWER_RIGHT;
    %M(len:len-3,len-7:len)=LOWER_RIGHT;
    
    for k=5:2:len-5
        H(k:k+1,k-4:k+5) = Q;
    end
    
     B(1:len,1:len)=P*H*B(1:len,1:len)*H'*P';
     
    len = len/2;
    
end

figure(2);
image(B);
colormap hot(16); %colormap hot(16);
title('Encoded')


%% Quantize
   %cutoff = 'enter the cutoff value'
  cutoff =.98

  len = size(B,1);
  X = sort(abs(B(:)));
  th = X(floor(cutoff*len^2));
  
 %% Built in quantization 
 bits = 8;

NP=2^(bits-1)-1; % number of partitions
[N1,N2]=size(B); % number of rows and columns -- size of the matrix
NX=N1*N2; % number of elements in the matrix?

a=abs(B(:));     % absolute value of matrix elements
SGN=sign(B(:));    % sign of matrix elements
MX=max(a);       % element of greatest magnitude

BQ = zeros(NP+1,1);
Codebook = zeros(NP+1,1);   % c stands for codebook
p = zeros(NP,1);     % p stands for partitions

Codebook(1) = 0;
d =(MX/th)^(1/NP);

for n=0:NP-1
    p(n+1)=th*d^n;
    Codebook(n+2)=th*d^(n+0);
end
BQ = quantiz(a,p);

 
 %[BQ,SGN,Codebook]= log_quant(B,th,8); 
  SGN = SGN+1; % preserve signs
 
  
 
%% TESTING -- unquantize
 

BQ3 = Codebook(BQ(:)+1);

SGN3=SGN-1; % get the signs back

BQ3=BQ3.*SGN3; 

%rearrange into a matrix
B=reshape(BQ3,256,256);


%% for DEcoding use LS & HS
clear A;
column1 = [LS4;HS3;LS2;HS1;LS0;HS1;LS2;HS3;LS4;0];
column2 = [0;HS4;LS3;HS2;LS1;HS0;LS1;HS2;LS3;HS4];
Q = [column1 column2];
upper_left = [LS0 LS1 LS2 LS3; 2*HS1 HS0+HS2 HS1+HS3 HS2+HS4; 2*LS2 LS1+LS3 LS0+LS4 LS1; 2*HS3 HS2+HS4 HS1 HS0; 2*LS4 LS3 LS2 LS1; 0 HS4 HS3 HS2; 0 0 LS4 LS3; 0 0 0 HS4];
lower_right = [LS4 0 0 0; HS3 HS4 0 0; LS2 LS3 LS4 0; HS1 HS2 HS3 2*HS4; LS0 LS1 LS2+LS4 2*LS3; HS1 HS0+HS4 HS3+HS1 2*HS2; LS2+LS4 LS1+LS3 LS0+LS2 2*LS1; HS3 HS2 HS1 HS0];



[len len ]= size(B);

len = 256;

I = eye(len);
PT = I([1:2:len],:);
PB = I([2:2:len],:);

 
A=B;
len2=8;

for j = 1:log2(len)-3
    
    len2 = 2*len2;
    clear H;
    P = [PT(1:len2/2,1:len2);
    PB(1:len2/2,1:len2)];
    
    % to do down to 8x8 use an if statemnt: if(j==1) run 8x8 matrix once, else .../ 

    H=zeros(len2,len2);
    
    for k = 1:2:len2-9
        H(1:8,1:4) = upper_left;
        H(len2-7:len2,len2-3:len2) = lower_right;  
        H(k:k+9,k+4:k+5)=Q;
    end
    
    %size(H)
    HE=H;
    % there is a dimensions error in the line below
    A(1:len2,1:len2)= HE'*P'*A(1:len2,1:len2)*P*HE;
    
end

figure(3);
imagesc(A);
colormap gray(256);
title('Recreated')


%% part (ii) compress the image without encoding



%% Compress BQ
file = 'BQ';
FMT='uint8';
fid=fopen(file,'w', 'l');
count = fwrite(fid,BQ, FMT);
status = fclose(fid);
%compress the file
gzip(file);

% compression ratios
working_path= pwd;

Compressed_BQ=strcat(working_path,'\',file,'.gz');

Compressed_BQ_stats = dir(Compressed_BQ);

compressed_BQ_bytes = Compressed_BQ_stats.bytes;



%% compress the original image
file = 'A1';
FMT='uint8';
fid=fopen(file,'w', 'l');
count = fwrite(fid,A1, FMT);
status = fclose(fid);
%compress the file
gzip(file);

Compressed_A1=strcat(working_path,'\',file,'.gz');

Compressed_A1_stats = dir(Compressed_A1);

compressed_A1_bytes = Compressed_A1_stats.bytes;

'compression ratio: Original/Quantized '
compression_ratio= compressed_A1_bytes/compressed_BQ_bytes